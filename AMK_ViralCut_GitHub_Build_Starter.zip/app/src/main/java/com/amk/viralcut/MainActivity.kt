package com.amk.viralcut

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViralCutScreen() }
    }
}

@Composable
fun ViralCutScreen() {
    var selectedVideo by remember { mutableStateOf("কোনো ভিডিও নির্বাচন করা হয়নি") }
    var link by remember { mutableStateOf("") }
    var clipCount by remember { mutableFloatStateOf(5f) }
    var message by remember { mutableStateOf("ভিডিও বেছে নিয়ে শুরু করো।") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) selectedVideo = uri.toString()
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("AMK ViralCut", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text("Long video থেকে short Reels তৈরির প্রজেক্ট")
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("১. ভিডিও নির্বাচন", fontWeight = FontWeight.Bold)
                        Text(selectedVideo, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { picker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                            Text("ফোন থেকে ভিডিও বেছে নাও")
                        }
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("২. ভিডিও লিংক", fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = link, onValueChange = { link = it },
                            label = { Text("YouTube / Facebook / TikTok / Instagram URL") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("লিংক ইমপোর্টের জন্য অনুমোদিত API বা বৈধ ডাউনলোড সোর্স প্রয়োজন।")
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("৩. কতটি ক্লিপ", fontWeight = FontWeight.Bold)
                        Text("${clipCount.toInt()} টি ক্লিপ")
                        Slider(value = clipCount, onValueChange = { clipCount = it }, valueRange = 1f..10f, steps = 8)
                    }
                }
                Button(
                    onClick = { message = "Starter app প্রস্তুত। AI highlight detection ও export backend পরবর্তী ধাপে যুক্ত করতে হবে।" },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ক্লিপ তৈরি শুরু") }
                Text(message)
                Text(
                    "নোট: এটি APK build করার starter app; এখনো AI highlight detection, caption, rendering/export এবং social link import যুক্ত হয়নি।",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
